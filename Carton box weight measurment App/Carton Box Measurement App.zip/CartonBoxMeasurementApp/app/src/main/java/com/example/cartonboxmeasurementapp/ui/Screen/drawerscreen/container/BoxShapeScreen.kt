package com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.container

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.R
import com.example.cartonboxmeasurementapp.item.NavigationBarItem
import com.example.cartonboxmeasurementapp.ui.viewmodel.CalculationViewModel
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents

@Composable
fun BoxShapeScreen(
    viewModel: CalculationViewModel,
    innerPadding: PaddingValues
) {

    var boxLength by remember {
        mutableStateOf("")
    }
    var boxWidth by remember {
        mutableStateOf("")
    }
    var boxHeight by remember {
        mutableStateOf("")
    }
    var showButton by remember { mutableStateOf(false) }
    val radioOptions = listOf("MM", "CM", "INCH")
    val (selectedOption, onOptionSelected) = remember { mutableStateOf(radioOptions[2]) }
    val options = listOf<String>("20 Feet", "40 Feet", "40 FeetHC")
    var selectedIndex by remember {
        mutableStateOf(0)
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = "Carton Box Load Ability ",
            fontWeight = MaterialTheme.typography.titleMedium.fontWeight,
            fontSize = MaterialTheme.typography.titleMedium.fontSize
        )
        Spacer(modifier = Modifier.height(10.dp))
        SingleChoiceSegmentedButtonRow {
            options.forEachIndexed { index, option ->
                SegmentedButton(
                    selected = selectedIndex == index,
                    onClick = { selectedIndex = index },
                    shape = SegmentedButtonDefaults.itemShape(
                        index = index,
                        count = options.size
                    )
                ) {
                    Text(text = option)
                }

            }
        }
        Row {
            radioOptions.forEach { text ->
                Row(
                    Modifier
                        .selectable(
                            selected = (text == selectedOption),
                            onClick = { onOptionSelected(text) }
                        ), horizontalArrangement = Arrangement.SpaceEvenly
                ) {

                    RadioButton(
                        selected = (text == selectedOption),
                        modifier = Modifier.padding(all = Dp(value = 8F)),
                        onClick = {
                            onOptionSelected(text)
                        }
                    )
                    Text(
                        text = text, modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp)
        ) {
            Row {
                OutlinedTextField(
                    value = boxLength, onValueChange = { boxLength = it },
                    label = { Text(text = "Length") },
                    modifier = Modifier
                        .padding(5.dp)
                        .weight(1f),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    )
                )
                OutlinedTextField(
                    value = boxWidth, onValueChange = { boxWidth = it },
                    label = { Text(text = "Width") },
                    modifier = Modifier
                        .padding(5.dp)
                        .weight(1f),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    )
                )

                OutlinedTextField(
                    value = boxHeight, onValueChange = { boxHeight = it },
                    label = { Text(text = "Height") },
                    modifier = Modifier
                        .padding(5.dp)
                        .weight(1f),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    )
                )
            }
        }


        if (boxHeight.isNotBlank() && boxLength.isNotBlank() && boxWidth.isNotBlank() &&
            boxLength.indexOf(",") == -1 && boxWidth.indexOf(",") == -1 && boxHeight.indexOf(",") == -1 &&
            boxLength.indexOf("-") == -1 && boxWidth.indexOf("-") == -1 && boxHeight.indexOf("-") == -1
        ) {
            var cbm = when (selectedIndex) {
                0 -> 28
                1 -> 56
                2 -> 68
                else -> 0
            }
            Button(onClick = {
                viewModel.loadAbilty(boxLength, boxWidth, boxHeight, selectedOption, cbm)
                showButton = true
            }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text(text = "Calculate")
            }
            Spacer(modifier = Modifier.height(10.dp))
            if (showButton) {
                Text(
                    text = "No of cartons : ${viewModel.boxLoadAbility}",
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    fontSize = MaterialTheme.typography.titleLarge.fontSize
                )
            }

        }


    }
}

@Composable
fun dropDownMenu() {



}