package com.example.cartonboxmeasurementapp.item

data class NavigationBarItem(
    val title:String,
    val route:String,
    val icon:Any
)