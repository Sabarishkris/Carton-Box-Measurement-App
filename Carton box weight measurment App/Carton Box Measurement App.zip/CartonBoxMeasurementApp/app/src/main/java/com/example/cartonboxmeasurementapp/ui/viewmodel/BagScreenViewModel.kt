package com.example.cartonboxmeasurementapp.ui.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cartonboxmeasurementapp.data.ReportRepository
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BagScreenViewModel @Inject constructor(  private val repository: ReportRepository):ViewModel() {
    var currentRoute by mutableStateOf(Route.NORMAL_BAG)
    private val _uiEvent = Channel<UiEvents>()
    val uiEvents = _uiEvent.receiveAsFlow()
    var perBagGram by mutableStateOf("")
    fun onSendUiEvent(events: UiEvents) {
        viewModelScope.launch {
            _uiEvent.send(events)
        }

    }

    fun onEvent(event: ReportScreenEvent) {
        when (event) {
            ReportScreenEvent.onAddReportClicked -> TODO()
            ReportScreenEvent.onBagScreenClicked -> TODO()
            ReportScreenEvent.onBoardCalculationClicked -> TODO()
            ReportScreenEvent.onBoxCalcluationClicked -> TODO()
            ReportScreenEvent.onContainerBoxScreenClicked -> TODO()
            is ReportScreenEvent.onDeleteReport -> TODO()
            ReportScreenEvent.onGumScreenClicked -> TODO()
            ReportScreenEvent.onHelpScreenClicked -> TODO()
            is ReportScreenEvent.onReportClicked -> TODO()
            ReportScreenEvent.onSaveReportClicked -> TODO()
            ReportScreenEvent.onWeightCalculationClicked -> TODO()
        }
    }

    fun bagCalculate(cuttingSize: Double, roll: Int,gsm:Int) {
        perBagGram=((cuttingSize*roll*gsm)/1550).toString()
    }

    fun handleBagCalculate(cuttingSize: Double, roll: Double) {
        perBagGram=((cuttingSize+roll)/1550).toString()


    }

    fun customizeCalculation(width: Double, height: Double, bagGsm: Double) {
        perBagGram=((width*height*bagGsm)/1550).toString()
    }
}