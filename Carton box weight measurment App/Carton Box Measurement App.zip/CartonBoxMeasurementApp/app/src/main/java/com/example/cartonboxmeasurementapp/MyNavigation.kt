package com.example.cartonboxmeasurementapp

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
//import com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.GsmScreen
//import com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.GumScreen
import com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.HelpScreen
import com.example.cartonboxmeasurementapp.ui.Screen.ReportViewScreen
import com.example.cartonboxmeasurementapp.ui.Screen.ReportsScreen
import com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.container.ContainerBoxScreen
import com.example.cartonboxmeasurementapp.ui.Screen.WeightCalculationScreen
import com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.bag.BagScreen
import com.example.cartonboxmeasurementapp.util.Route

@Composable
fun MyNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Route.REPORT_LIST) {
        composable(route = Route.REPORT_LIST,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            ReportsScreen(navController)
        }
        composable(
            route = Route.VIEW_REPORT + "?reportId={reportId}",
            arguments = listOf(navArgument(name = "reportId") {
                type = NavType.IntType
                defaultValue = -1
            }),

            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            ReportViewScreen(navController)
        }
        composable(route = Route.WEIGHT_CALCULATION_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            WeightCalculationScreen(navController = navController)
        }
        composable(route = Route.BAG_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
           BagScreen(navController)
        }
//        composable(route = Route.BOARD_SCREEN,
//            enterTransition = {
//                scaleIntoContainer()
//            },
//            exitTransition = {
//                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
//            },
//            popEnterTransition = {
//                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
//            },
//            popExitTransition = {
//                scaleOutOfContainer()
//            }
//        ) {
//           BoardCalculationScreen(navController = navController)
//        }
//        composable(route = Route.GUM_SCREEN,
//            enterTransition = {
//                scaleIntoContainer()
//            },
//            exitTransition = {
//                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
//            },
//            popEnterTransition = {
//                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
//            },
//            popExitTransition = {
//                scaleOutOfContainer()
//            }
//        ) {
//            GumScreen(navController)
//        }
//        composable(route = Route.GSM_SCREEN,
//            enterTransition = {
//                scaleIntoContainer()
//            },
//            exitTransition = {
//                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
//            },
//            popEnterTransition = {
//                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
//            },
//            popExitTransition = {
//                scaleOutOfContainer()
//            }
//        ) {
//            GsmScreen(navController)
//        }
        composable(route = Route.HELP_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            HelpScreen(navController)
        }
        composable(route = Route.CONTAINER_BOX_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            ContainerBoxScreen(navController)
        }
    }
}


fun scaleIntoContainer(
    direction: ScaleTransitionDirection = ScaleTransitionDirection.INWARDS,
    initialScale: Float = if (direction == ScaleTransitionDirection.OUTWARDS) 0.9f else 1.1f
): EnterTransition {
    return scaleIn(
        animationSpec = tween(220, delayMillis = 90),
        initialScale = initialScale
    ) + fadeIn(animationSpec = tween(220, delayMillis = 90))
}

fun scaleOutOfContainer(
    direction: ScaleTransitionDirection = ScaleTransitionDirection.OUTWARDS,
    targetScale: Float = if (direction == ScaleTransitionDirection.INWARDS) 0.9f else 1.1f
): ExitTransition {
    return scaleOut(
        animationSpec = tween(
            durationMillis = 220,
            delayMillis = 90
        ), targetScale = targetScale
    ) + fadeOut(tween(delayMillis = 90))
}

enum class ScaleTransitionDirection {
    INWARDS,
    OUTWARDS
}


//enterTransition = {
//    when (initialState.destination.route) {
//        "details" ->
//            slideIntoContainer(
//                AnimatedContentTransitionScope.SlideDirection.Left,
//                animationSpec = tween(700)
//            )
//
//        else -> null
//    }
//},
//exitTransition = {
//    when (targetState.destination.route) {
//        "details" ->
//            slideOutOfContainer(
//                AnimatedContentTransitionScope.SlideDirection.Left,
//                animationSpec = tween(700)
//            )
//
//        else -> null
//    }
//},
//popEnterTransition = {
//    when (initialState.destination.route) {
//        "details" ->
//            slideIntoContainer(
//                AnimatedContentTransitionScope.SlideDirection.Right,
//                animationSpec = tween(700)
//            )
//
//        else -> null
//    }
//},
//popExitTransition = {
//    when (targetState.destination.route) {
//        "details" ->
//            slideOutOfContainer(
//                AnimatedContentTransitionScope.SlideDirection.Right,
//                animationSpec = tween(700)
//            )
//
//        else -> null
//    }
//}
//) {