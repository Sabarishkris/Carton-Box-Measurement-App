package com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.bag

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.R
import com.example.cartonboxmeasurementapp.item.NavigationBarItem
import com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.container.BottomNavigation
import com.example.cartonboxmeasurementapp.ui.viewmodel.BagScreenViewModel
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BagScreen(navController: NavHostController,viewModel: BagScreenViewModel= hiltViewModel()) {

    val scaffold = remember {
        SnackbarHostState()
    }

    val items = listOf(
        NavigationBarItem(
            "Bag ",
            Route.NORMAL_BAG,
            icon = Icons.Filled.Menu
        ),
        NavigationBarItem(
            "Handle Bag",
            Route.HANDLE_BAG,
            icon = R.drawable.bag
        ),
        NavigationBarItem(
            "Customize Bag",
            Route.NORMAL_BAG_CUSTOMIZE,
            icon = Icons.Default.Settings
        )
    )

    LaunchedEffect(key1 = true) {
        viewModel.uiEvents.collect { event ->
            when (event) {
                is UiEvents.ShowSnackBar -> {
                    scaffold.showSnackbar(
                        message = event.message
                    )
                }

                UiEvents.PopBackStack -> {
                    navController.popBackStack()
                }

                else -> Unit
            }
        }
    }
    Scaffold(
        snackbarHost = { SnackbarHost(scaffold, modifier = Modifier.padding(bottom = 80.dp)) },
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Regular Bag",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        navController.popBackStack()
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

            )

        }, bottomBar = {
            BottomNavigation(items = items, currentScreen = viewModel.currentRoute) {
                viewModel.currentRoute = it
            }
        }
    ) { innerPadding ->
        when (viewModel.currentRoute) {
            Route.NORMAL_BAG -> NormalBagScreen(viewModel, innerPadding)
            Route.HANDLE_BAG-> HandleBagScreen(viewModel, innerPadding)
            Route.NORMAL_BAG_CUSTOMIZE -> NormalBagCustomizeScreen(viewModel, innerPadding)
        }

    }



}