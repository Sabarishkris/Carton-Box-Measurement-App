package com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.R
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.ui.viewmodel.CalculationViewModel
import com.example.cartonboxmeasurementapp.util.UiEvents
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(navigate: NavHostController, viewModel: CalculationViewModel = hiltViewModel()) {

    val scaffold = remember { SnackbarHostState() }

    LaunchedEffect(key1 = true) {
        viewModel.uiEvents.collect { event ->
            when (event) {
                is UiEvents.ShowSnackBar -> {
                    scaffold.showSnackbar(
                        message = event.message
                    )
                }

                UiEvents.PopBackStack -> {
                    navigate.popBackStack()
                }

                else -> Unit
            }
        }
    }
    Surface(
        modifier = Modifier.fillMaxSize()
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("FAQ ") },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    navigationIcon = {
                        IconButton(onClick = {
                            navigate.popBackStack()
                        }) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                )
            }

        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Top,
            ) {
//                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = " 1)  What is mean by Layer ? ",
                    fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = "         In Packaging ,the terms 'Ply' refers to the number of layers or sheets of material used in the construction of a box.The layers impact the box's strength,durability, and cushioning properties.",
                    fontSize = MaterialTheme.typography.titleSmall.fontSize,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = "For Example : ",
                    fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = " 3-Ply ",
                    fontSize = MaterialTheme.typography.titleMedium.fontSize,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = "Structure : Consists of one layer of corrugated paper sandwiched between two liners(Outer and Inner).",
                    fontSize = MaterialTheme.typography.titleSmall.fontSize,
                    modifier = Modifier.padding(5.dp)
                )
                Image(
                    painter = painterResource(id = R.drawable.layer),
                    contentDescription = "layer",
                    modifier = Modifier.padding(5.dp).align(Alignment.CenterHorizontally)
                )

                HorizontalDivider(modifier = Modifier.padding(5.dp))


                Text(
                    text = " 2)  How to identify the dimension which is length ? which is width ?  which is height ?",
                    fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = "Length :",
                    fontSize = MaterialTheme.typography.titleMedium.fontSize,
                    fontWeight = MaterialTheme.typography.titleMedium.fontWeight,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = " The Longest side of the carton. When the box is oriented with the opening facing up,this is usually the dimension measured from front to back.",
                    fontSize = MaterialTheme.typography.titleSmall.fontSize,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = "Width :  ",
                    fontSize = MaterialTheme.typography.titleMedium.fontSize,
                    fontWeight = MaterialTheme.typography.titleMedium.fontWeight,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = "The shorter side of the carton when viewed from the same orientation.It's measured from side to side.",
                    fontSize = MaterialTheme.typography.titleSmall.fontSize,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = "Height :  ",
                    fontSize = MaterialTheme.typography.titleMedium.fontSize,
                    fontWeight = MaterialTheme.typography.titleMedium.fontWeight,
                    modifier = Modifier.padding(5.dp)
                )
                Text(
                    text = "The dimension from the base to the top of the carton.It's measured vertically when the box is placed with its opening facing up.",
                    fontSize = MaterialTheme.typography.titleSmall.fontSize,
                    modifier = Modifier.padding(5.dp)
                )

                Image(
                    painter = painterResource(id = R.drawable.cartonbox),
                    contentDescription = "layer",
                    modifier = Modifier.padding(5.dp).align(Alignment.CenterHorizontally)
                )

                HorizontalDivider(modifier = Modifier.padding(5.dp))


            }
        }

    }
}