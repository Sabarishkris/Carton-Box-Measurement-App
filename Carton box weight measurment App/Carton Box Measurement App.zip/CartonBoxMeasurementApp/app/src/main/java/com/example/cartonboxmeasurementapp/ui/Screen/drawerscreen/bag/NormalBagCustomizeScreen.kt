package com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.bag

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import com.example.cartonboxmeasurementapp.ui.viewmodel.BagScreenViewModel

@Composable
fun NormalBagCustomizeScreen(viewModel: BagScreenViewModel, innerPadding: PaddingValues) {
    var bagGsm by remember { mutableStateOf("0") }
    var palamGsm by remember { mutableStateOf("") }
    var width by remember {
        mutableStateOf("0.0")
    }
    var height by remember {
        mutableStateOf("0.0")
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally) {
            Row (horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically){

//            Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = width,
                    onValueChange = { width = it },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    ),
                    label = { Text("Width") },
                )
                Spacer(modifier = Modifier.width(3.dp))
                OutlinedTextField(
                    value = height,
                    onValueChange = { height = it },
                    modifier = Modifier
                        .weight(1f),
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    ),
                    label = { Text("Height") },
                )
            }
            OutlinedTextField(
                value = bagGsm,
                onValueChange = { bagGsm = it },
                modifier = Modifier
                    .fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                label = { Text("Bag Gsm") },
            )
//            OutlinedTextField(
//                value = palamGsm,
//                onValueChange = { palamGsm = it },
//                modifier = Modifier
//                    .fillMaxWidth(),
//                keyboardOptions = KeyboardOptions(
//                    autoCorrect = false,
//                    keyboardType = KeyboardType.Number,
//                    imeAction = ImeAction.Done
//                ),
//                label = { Text("Palam Gsm") },
//            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(onClick = {
//                if(width.isNotBlank() && height.isNotBlank() && bagGsm.isNotBlank() && palamGsm.isBlank()){
//                    viewModel.customizeCalculation(width.toDouble() ,height.toDouble(),bagGsm.toDouble())
//                }else
                    if(width.isNotBlank() && height.isNotBlank() && bagGsm.isNotBlank() ) {
                    viewModel.customizeCalculation(
                        width.toDouble(),
                        height.toDouble(),
                        bagGsm.toDouble()
                    )
                }
            }) {
                Text(text = "Calculate")

            }
            Spacer(modifier = Modifier.height(10.dp))
            if (viewModel.perBagGram.isNotBlank())
                Text(
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    text = "Per bag : " +
                            "${
                                String.format(
                                    "%.3f",
                                    viewModel.perBagGram.toDouble()
                                )
                            } gram "
                )
        }
    }
}