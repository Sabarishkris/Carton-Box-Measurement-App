package com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.container

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.R
import com.example.cartonboxmeasurementapp.item.NavigationBarItem
import com.example.cartonboxmeasurementapp.ui.viewmodel.CalculationViewModel
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents

//@Preview(showBackground = true)
@SuppressLint("UnrememberedMutableState")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContainerBoxScreen(
    navigate: NavHostController,
    viewModel: CalculationViewModel = hiltViewModel()
) {

    val scaffold = remember {
        SnackbarHostState()
    }

//    var currentRoute by remember {
//        mutableStateOf(Route.BOX_SHAPE)
//    }
    val items = listOf(
        NavigationBarItem(
            "Box",
            Route.BOX_SHAPE,
            icon = R.drawable.boxselectedicon
        ),
        NavigationBarItem(
            "Cylinder",
            Route.CYLINDER_SHAPE,
            icon = Icons.Default.CheckCircle
        )
    )

    LaunchedEffect(key1 = true) {
        viewModel.uiEvents.collect { event ->
            when (event) {
                is UiEvents.ShowSnackBar -> {
                    scaffold.showSnackbar(
                        message = event.message
                    )
                }

                UiEvents.PopBackStack -> {
                    navigate.popBackStack()
                }

                else -> Unit
            }
        }
    }
    Scaffold(
        snackbarHost = { SnackbarHost(scaffold, modifier = Modifier.padding(bottom = 80.dp)) },
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Load Ability",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        navigate.popBackStack()
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

            )

        }, bottomBar = {
            BottomNavigation(items = items, currentScreen = viewModel.currentRoute) {
                viewModel.currentRoute = it
            }
        }
    ) { innerPadding ->
        when (viewModel.currentRoute) {
            Route.BOX_SHAPE -> BoxShapeScreen(viewModel, innerPadding)
            Route.CYLINDER_SHAPE -> CylinderShapeScreen(viewModel, innerPadding)
        }

    }

//        SnackbarHost(
//            hostState = scaffold,
//            modifier = Modifier.align(Alignment.CenterVertically)
//        )


}


@Composable
fun BottomNavigation(
    items: List<NavigationBarItem> = listOf(),
    currentScreen: String,
    onItemClick: (String) -> Unit
) {
    NavigationBar {
        items.forEach { item ->
            NavigationBarItem(
                selected = currentScreen == item.route,
                label = { Text(text = item.title) }, onClick = { onItemClick(item.route) },
                alwaysShowLabel = currentScreen == item.route,
                icon = @Composable {
                    if (item.icon is ImageVector) {
                        Icon(imageVector = item.icon, contentDescription = "")
                    } else {
                        Icon(
                            painter = painterResource(id = item.icon as Int),
                            contentDescription = "",
                            modifier = Modifier.size(30.dp)
                        )
                    }
                })


        }
    }
}
