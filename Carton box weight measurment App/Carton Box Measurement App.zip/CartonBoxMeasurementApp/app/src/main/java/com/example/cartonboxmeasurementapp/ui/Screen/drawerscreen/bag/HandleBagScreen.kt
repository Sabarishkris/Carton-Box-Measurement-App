package com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.bag

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import com.example.cartonboxmeasurementapp.ui.viewmodel.BagScreenViewModel

@Composable
fun HandleBagScreen(viewModel: BagScreenViewModel, innerPadding: PaddingValues) {

    var expanded1 by remember { mutableStateOf(false) }
    var expanded2 by remember { mutableStateOf(false) }
    val suggestions = listOf(
        "15.75 x 19 x 47 (Pa)",
        "15.75 x 19 x 43 (S.P)",
        "14 x 17 x 8 (P.P)",
        "14 x 17 x 7 (P.P)",
        "12 x 14 x 8 (P.P)",
        "12 x 14 x 7 (P.P)",
        "12 x 14 x 42 (S.P)"
    )
//    val cutting = listOf("46", "47", "49", "55", "23", "29")
    var bagSize by remember { mutableStateOf(suggestions[0]) }
//    var cuttingSize by remember { mutableStateOf(cutting[0]) }
    val context = LocalContext.current
    var textfieldSize by remember { mutableStateOf(Size.Zero) }
    var bagGsm by remember { mutableStateOf("0") }
    var palamGsm by remember { mutableStateOf("0") }

    val icon1 = if (expanded1)
        Icons.Filled.KeyboardArrowUp
    else
        Icons.Filled.KeyboardArrowDown

    val icon2 = if (expanded2)
        Icons.Filled.KeyboardArrowUp
    else
        Icons.Filled.KeyboardArrowDown

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            OutlinedTextField(
                value = bagSize,
                onValueChange = { bagSize = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { coordinates ->
                        //This value is used to assign to the DropDown the same width
                        textfieldSize = coordinates.size.toSize()
                    },
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                ),
                label = { Text("Bag Size") },
                trailingIcon = {
                    Icon(icon1, "contentDescription",
                        Modifier.clickable { expanded1 = !expanded1 })
                }
            )

            DropdownMenu(
                expanded = expanded1,
                onDismissRequest = { expanded1 = false },
                modifier = Modifier
                    .width(with(LocalDensity.current) { textfieldSize.width.toDp() })
            ) {
                suggestions.forEach { label ->
                    DropdownMenuItem(text = { Text(text = label) },
                        onClick = {
                            bagSize = label
                            expanded1 = false
                        })
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = bagGsm,
                onValueChange = { bagGsm = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { coordinates ->
                        //This value is used to assign to the DropDown the same width
                        textfieldSize = coordinates.size.toSize()
                    },
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                label = { Text("Bag Gsm") },
            )
            Spacer(modifier = Modifier.height(10.dp))
            if (bagSize.equals("15.75 x 19 x 47 (Pa)") ||
                bagSize.equals("15.75 x 19 x 43 (S.P)") ||
                bagSize.equals("12 x 14 x 42 (S.P)")
            ) {
                OutlinedTextField(
                    value = palamGsm,
                    onValueChange = { palamGsm = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .onGloballyPositioned { coordinates ->
                            //This value is used to assign to the DropDown the same width
                            textfieldSize = coordinates.size.toSize()
                        },
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    label = { Text("Palam Gsm") },
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(modifier = Modifier.align(Alignment.CenterHorizontally),
                onClick = {
                    if (bagSize.equals("15.75 x 19 x 47 (Pa)") && bagGsm.isNotBlank() && palamGsm.isNotBlank()) {
                        viewModel.handleBagCalculate(
                            14.5 * 5.25 * palamGsm.toInt() * 2,
                            15.75 * 47.0 * bagGsm.toInt()
                        )
                    } else if (bagSize.equals("15.75 x 19 x 43 (S.P)") && bagGsm.isNotBlank() && palamGsm.isNotBlank()) {
                        viewModel.handleBagCalculate(
                            5.25 * 55 * palamGsm.toInt(),
                            15.75 * 43.0 * bagGsm.toInt()
                        )
                    } else if (bagSize.equals("14 x 17 x 8 (P.P)") && bagGsm.isNotBlank()) {
                        viewModel.handleBagCalculate(18.0 * 29.0 * bagGsm.toInt(), 8.0 * 2.25)
                    } else if (bagSize.equals("14 x 17 x 7 (P.P)") && bagGsm.isNotBlank()) {
                        viewModel.handleBagCalculate(18.0 * 29.0 * bagGsm.toInt(), 7.0 * 2.25)
                    } else if (bagSize.equals("12 x 14 x 8 (P.P)") && bagGsm.isNotBlank()) {
                        viewModel.handleBagCalculate(14.75 * 24.0 * bagGsm.toInt(), 8.0 * 2.0)
                    } else if (bagSize.equals("12 x 14 x 7 (P.P)") && bagGsm.isNotBlank()) {
                        viewModel.handleBagCalculate(14.75 * 24 * bagGsm.toInt(), 7.0 * 2.0)
                    } else if (bagSize.equals("12 x 14 x 42 (S.P)") && bagGsm.isNotBlank() && palamGsm.isNotBlank()) {
                        viewModel.handleBagCalculate(5.25 * 42 * palamGsm.toInt(), 14.75 * 24 * bagGsm.toInt())
                    } else {
                        Toast.makeText(context, "Invalid Bag size ", Toast.LENGTH_SHORT).show()
                    }
                }) {
                Text(modifier = Modifier.padding(5.dp), text = "Calculate")
            }
            Spacer(modifier = Modifier.height(10.dp))
            if (viewModel.perBagGram.isNotBlank())
                Text(
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    text = "Per bag : " +
                            "${
                                String.format(
                                    "%.3f",
                                    viewModel.perBagGram.toDouble()
                                )
                            } gram "
                )

        }
    }
}