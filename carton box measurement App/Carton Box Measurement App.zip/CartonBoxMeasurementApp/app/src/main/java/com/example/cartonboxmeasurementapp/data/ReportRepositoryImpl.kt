package com.example.cartonboxmeasurementapp.data

import kotlinx.coroutines.flow.Flow

class ReportRepositoryImpl(private val dao: ReportDao):ReportRepository {

    override suspend fun insert(report: Report) {
       dao.insert(report)
    }

    override suspend fun delete(report: Report) {
      dao.delete(report)
    }

    override suspend fun getReportById(id: Int): Report? {
        return dao.getReportById(id)
    }

    override fun getReports(): Flow<List<Report>> {
        return dao.getReports()
    }

}