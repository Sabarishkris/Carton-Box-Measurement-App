package com.example.cartonboxmeasurementapp.ui.Screen

import android.annotation.SuppressLint
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.R
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.ui.viewmodel.CalculationViewModel
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents
import dagger.hilt.android.qualifiers.ApplicationContext

@SuppressLint("UnrememberedMutableState")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoardCalculationScreen(
    navController: NavHostController,
    viewModel: CalculationViewModel = hiltViewModel()
) {
    var boxLength by mutableStateOf("")
    var boxHeight by mutableStateOf("")

    val scaffold = remember {
        SnackbarHostState()
    }

    val uiEvents = viewModel.uiEvents.collectAsState(initial = null)
    val scaffoldState = remember { SnackbarHostState() }
    uiEvents.value?.let { event ->
        LaunchedEffect(key1 = event) {
            Log.d("msgl", "enter")
            when (event) {
                is UiEvents.Navigate -> {
                    if (event.route != Route.BOARD_SCREEN) {
                        navController.navigate(event.route)
                    }
                }

                is UiEvents.ShowSnackBar -> {
                    scaffoldState.showSnackbar(
                        message = event.message
                    )
                }

                else -> Unit
            }
        }
    }
    Scaffold(snackbarHost = { SnackbarHost(scaffold, modifier = Modifier.padding(bottom = 80.dp)) },
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Board Calculation",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        navController.popBackStack(
                            route = Route.REPORT_LIST,
                            inclusive = false
                        )
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }, actions = {
                    if (viewModel.companyName.isNotBlank() && boxLength.isNotBlank() && boxHeight.isNotBlank()) {
                        IconButton(onClick = {
                            viewModel.onEvent(ReportScreenEvent.onSaveReportClicked)
                            if (viewModel.weight.isNotBlank()) {
                                navController.popBackStack(
                                    route = Route.REPORT_LIST,
                                    inclusive = false
                                )
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Save",
                                tint = MaterialTheme.colorScheme.onSurface
                            )

                        }
                    }
                }
            )

        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                contentColor = MaterialTheme.colorScheme.onSurface
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        modifier = Modifier
                            .padding(8.dp)
                            .clickable { viewModel.onEvent(ReportScreenEvent.onBoxCalcluationClicked) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            painter = if (!viewModel.BoxScreen) painterResource(id = R.drawable.boxselectedicon) else painterResource(
                                id = R.drawable.boxunselecticon
                            ),
                            contentDescription = "Box",
                            modifier = Modifier
                                .width(30.dp)
                                .height(30.dp)
                        )
                        Text(text = "Box", style = MaterialTheme.typography.bodySmall)
                    }
                    Column(
                        modifier = Modifier
                            .padding(8.dp)
                            .clickable { viewModel.onEvent(ReportScreenEvent.onBoardCalculationClicked) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            painter = if (!viewModel.BoardScreen) painterResource(id = R.drawable.selectedboard) else painterResource(
                                id = R.drawable.unselectboard
                            ),
                            contentDescription = "Board",
                            modifier = Modifier
                                .width(30.dp)
                                .height(30.dp)
                        )
                        Text(text = "Board", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = viewModel.companyName, onValueChange = { viewModel.companyName = it },
                label = { Text(text = "Company Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1
            )
            viewModel.joint = "Single"
            viewModel.singleJoint = false

            OutlinedTextField(
                value = viewModel.ply, onValueChange = { viewModel.ply = it },
                label = { Text(text = "Board Layer") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrectEnabled = false,
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                )
            )
            OutlinedTextField(
                value = viewModel.gsm, onValueChange = { viewModel.gsm = it },
                label = { Text(text = "Total GSM") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                )
            )
            OutlinedTextField(
                value = viewModel.reelSize, onValueChange = { viewModel.reelSize = it },
                label = { Text(text = "Reel Size in inch") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                )
            )
            OutlinedTextField(
                value = viewModel.boxCount, onValueChange = { viewModel.boxCount = it },
                label = { Text(text = "Per board Box Count") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                )
            )
            Row {
                OutlinedTextField(
                    value = boxLength, onValueChange = { boxLength = it },
                    label = { Text(text = "Board Length") },
                    modifier = Modifier
                        .padding(5.dp)
                        .weight(1f),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    )
                )

                OutlinedTextField(
                    value = boxHeight, onValueChange = { boxHeight = it },
                    label = { Text(text = "Board Height") },
                    modifier = Modifier
                        .padding(5.dp)
                        .weight(1f),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    )
                )
            }
            if (boxHeight.isNotBlank() && boxLength.isNotBlank()
                && viewModel.gsm.isNotBlank() &&
                viewModel.boxCount.isNotBlank()
            ) {
                if (boxLength.equals(viewModel.reelSize) || boxHeight.equals(viewModel.reelSize)) {
                    viewModel.boxSize = "empty"
                    viewModel.boardSize = "$boxLength\" x $boxHeight\" Inch"
                    viewModel.boardCalcluation(boxLength, boxHeight)

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(modifier = Modifier.fillMaxWidth().padding(10.dp)
                        .align(Alignment.CenterHorizontally)
                        .background(color = MaterialTheme.colorScheme.surfaceContainer, shape = RoundedCornerShape(50.dp))

                        ) {
                            Text(
                                text = "Per Box Weight :  ${viewModel.weight}",
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(5.dp).align(Alignment.Center),
                                fontSize = MaterialTheme.typography.bodyLarge.fontSize
                            )

                    }
                    Text(
                        text = "This weight include box production waste it will differ -15 gram to -25 gram",
                        modifier = Modifier
                            .padding(5.dp)
                            .align(Alignment.CenterHorizontally),
                        textAlign = TextAlign.Center
                    )

                } else {
                    Toast.makeText(LocalContext.current, "Invalid Board Size ", Toast.LENGTH_SHORT)
                        .show()
                }
            }

        }
    }


}