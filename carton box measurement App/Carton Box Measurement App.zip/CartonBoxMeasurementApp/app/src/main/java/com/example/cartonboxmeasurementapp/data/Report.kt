package com.example.cartonboxmeasurementapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Report(
    var companyName :String,
    var joint:String,
    var singleJoint:Boolean,
    var ply:String,
    var gsm:String,
    var reelSize:String,
    var boxCount:String,
    var boxSize:String?,
    var boardSize:String?,
//    var length:Double=0.0,
//    var width:Double=0.0,
//    var height:Double=0.0,
//    var bLength:Double=0.0,
//    var bHeight:Double=0.0,
    var weight:String,
    @PrimaryKey
    var id:Int?=null,
)
