package com.example.cartonboxmeasurementapp.ui.Screen

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.R
import com.example.cartonboxmeasurementapp.item.NavigationBarItem
import com.example.cartonboxmeasurementapp.ui.Screen.drawerscreen.container.BottomNavigation
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.ui.viewmodel.CalculationViewModel
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeightCalculationScreen(
    navController: NavHostController,
    viewModel: CalculationViewModel = hiltViewModel(),
) {
    val scaffold = remember {
        SnackbarHostState()
    }
    var currentRoute by remember {
        mutableStateOf(Route.BOX_SCREEN)
    }
    val items = listOf(
        NavigationBarItem(
            "Box",
            Route.BOX_SCREEN,
            icon = R.drawable.boxselectedicon
        ),
        NavigationBarItem(
            "Board",
            Route.BOARD_SCREEN,
            icon = R.drawable.selectedboard
        )
    )
    Scaffold(snackbarHost = { SnackbarHost(scaffold, modifier = Modifier.padding(bottom = 80.dp)) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Weight Calculation",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        navController.popBackStack(
                            route = Route.REPORT_LIST,
                            inclusive = false
                        )
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }, actions = {
                    if (viewModel.companyName.isNotBlank()
                        && viewModel.boxLength.isNotBlank()
                        && viewModel.boxWidth.isNotBlank()
                        && viewModel.boxHeight.isNotBlank()
                        && viewModel.boardLength.isNotBlank()
                        && viewModel.boxHeight.isNotBlank()
                    ) {
                        IconButton(onClick = {
                            viewModel.onEvent(ReportScreenEvent.onSaveReportClicked)
                            if (viewModel.weight.isNotBlank()) {
                                navController.popBackStack(
                                    route = Route.REPORT_LIST,
                                    inclusive = false
                                )
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Save",
                                tint = MaterialTheme.colorScheme.onSurface
                            )

                        }
                    }
                }
            )

        },
        bottomBar = {
            BottomNavigation(items = items, currentScreen = currentRoute) {
                currentRoute = it
            }
        }
    ) { innerPadding ->
        when (currentRoute) {
            Route.BOX_SCREEN -> {
                viewModel.boxLength = ""
                viewModel.boxWidth = ""
                viewModel.boxHeight = ""
                BoxScreen(innerPadding, viewModel)
            }

            Route.BOARD_SCREEN -> {
                viewModel.boardLength = ""
                viewModel.boardHeight = ""
                BoardScreen(innerPadding, viewModel)
            }
        }
    }

}

@Composable
fun BoardScreen(innerPadding: PaddingValues, viewModel: CalculationViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .verticalScroll(rememberScrollState())
    ) {
        OutlinedTextField(
            value = viewModel.companyName, onValueChange = { viewModel.companyName = it },
            label = { Text(text = "Company Name") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            singleLine = true,
            maxLines = 1
        )
        viewModel.joint = "Single"
        viewModel.singleJoint = false

        OutlinedTextField(
            value = viewModel.ply, onValueChange = { viewModel.ply = it },
            label = { Text(text = "Board Layer") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            singleLine = true,
            maxLines = 1,
            keyboardOptions = KeyboardOptions(
                autoCorrectEnabled = false,
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            )
        )
        OutlinedTextField(
            value = viewModel.gsm, onValueChange = { viewModel.gsm = it },
            label = { Text(text = "Total GSM") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            singleLine = true,
            maxLines = 1,
            keyboardOptions = KeyboardOptions(
                autoCorrect = false,
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            )
        )
        OutlinedTextField(
            value = viewModel.reelSize, onValueChange = { viewModel.reelSize = it },
            label = { Text(text = "Reel Size in inch") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            singleLine = true,
            maxLines = 1,
            keyboardOptions = KeyboardOptions(
                autoCorrect = false,
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            )
        )
        OutlinedTextField(
            value = viewModel.boxCount, onValueChange = { viewModel.boxCount = it },
            label = { Text(text = "Per board Box Count") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            singleLine = true,
            maxLines = 1,
            keyboardOptions = KeyboardOptions(
                autoCorrect = false,
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            )
        )
        Row {
            OutlinedTextField(
                value = viewModel.boardLength, onValueChange = { viewModel.boardLength = it },
                label = { Text(text = "Board Length") },
                modifier = Modifier
                    .padding(5.dp)
                    .weight(1f),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                )
            )
            viewModel.boxLength = "empty"
            viewModel.boxWidth = "empty"
            viewModel.boxHeight = "empty"
            OutlinedTextField(
                value = viewModel.boardHeight, onValueChange = { viewModel.boardHeight = it },
                label = { Text(text = "Board Height") },
                modifier = Modifier
                    .padding(5.dp)
                    .weight(1f),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                )
            )
        }
        if (viewModel.boardHeight.isNotBlank() && viewModel.boardLength.isNotBlank()
            && viewModel.gsm.isNotBlank() &&
            viewModel.boxCount.isNotBlank() &&
            viewModel.boardLength.indexOf(",") == -1 && viewModel.boardHeight.indexOf(",") == -1 &&
            viewModel.boardLength.indexOf("-") == -1 && viewModel.boardHeight.indexOf("-") == -1
        ) {
            if (viewModel.boardLength.equals(viewModel.reelSize) || viewModel.boardHeight.equals(
                    viewModel.reelSize
                )
            ) {
                viewModel.boxSize = "empty"
                viewModel.boardSize = "${viewModel.boardLength}\" x ${viewModel.boardHeight}\" Inch"
                viewModel.boardCalcluation(viewModel.boardLength, viewModel.boardHeight)

                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp)
                        .align(Alignment.CenterHorizontally)
                        .background(
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            shape = RoundedCornerShape(50.dp)
                        )

                ) {
                    Text(
                        text = "Per Box Weight :  ${viewModel.weight}",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(5.dp)
                            .align(Alignment.Center),
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize
                    )

                }
                Text(
                    text = "This weight include box production waste it will differ -15 gram to -25 gram",
                    modifier = Modifier
                        .padding(5.dp)
                        .align(Alignment.CenterHorizontally),
                    textAlign = TextAlign.Center
                )

            } else {
                Toast.makeText(LocalContext.current, "Invalid Board Size ", Toast.LENGTH_SHORT)
                    .show()
            }
        }

    }
}

@Composable
fun BoxScreen(innerPadding: PaddingValues, viewModel: CalculationViewModel) {
    var checked by remember {
        mutableStateOf(false)
    }
    var tempWidth: String? = null
//    var length by mutableStateOf("")
//    var width by mutableStateOf("")
    val radioOptions = listOf("MM", "CM", "INCH")
    val (selectedOption, onOptionSelected) = remember { mutableStateOf(radioOptions[2]) }
//    var height by mutableStateOf("")
//    val uiEvents = viewModel.uiEvents.collectAsState(initial = null)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .verticalScroll(rememberScrollState())
    ) {

        OutlinedTextField(
            value = viewModel.companyName, onValueChange = { viewModel.companyName = it },
            label = { Text(text = "Company Name") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            singleLine = true,
            maxLines = 1
        )
        viewModel.joint = "Single"
        viewModel.singleJoint = false

        OutlinedTextField(
            value = viewModel.ply, onValueChange = { viewModel.ply = it },
            label = { Text(text = "Box Layer") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            singleLine = true,
            maxLines = 1,
            keyboardOptions = KeyboardOptions(
                autoCorrect = false,
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            )
        )
        OutlinedTextField(
            value = viewModel.gsm, onValueChange = { viewModel.gsm = it },
            label = { Text(text = "Total GSM") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            singleLine = true,
            maxLines = 1,
            keyboardOptions = KeyboardOptions(
                autoCorrect = false,
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            )
        )
        Row {
            OutlinedTextField(
                value = viewModel.reelSize, onValueChange = { viewModel.reelSize = it },
                label = { Text(text = "Reel Size in inch") },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                )
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Match reel Size")
                Checkbox(checked = checked, onCheckedChange = { checked = it })
            }
        }
        if (checked) {
            OutlinedTextField(
                value = viewModel.boxCount, onValueChange = { viewModel.boxCount = it },
                label = { Text(text = "Box Count") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                )
            )
//                viewModel.boxCount="1"
            if (viewModel.boxCount.isNotBlank() && viewModel.reelSize.isNotBlank()) {
                try {
                    val temp: Double =
                        viewModel.reelSize.toDouble() / viewModel.boxCount.toDouble()
                    tempWidth = temp.toString()
                } catch (e: Exception) {
                    e.printStackTrace()
                    UiEvents.ShowSnackBar("Invalid Box Count number")
                }

                Log.e("Except", "$tempWidth")
            }


        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp)
        ) {
            Row {
                radioOptions.forEach { text ->
                    Row(
                        Modifier
                            .selectable(
                                selected = (text == selectedOption),
                                onClick = { onOptionSelected(text) }
                            ), horizontalArrangement = Arrangement.SpaceEvenly
                    ) {

                        RadioButton(
                            selected = (text == selectedOption),
                            modifier = Modifier.padding(all = Dp(value = 8F)),
                            onClick = {
                                onOptionSelected(text)
                            }
                        )
                        Text(
                            text = text, modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
            }
        }
        Row(
            modifier = Modifier.padding(5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            viewModel.boardLength = "empty"
            viewModel.boardHeight = "empty"
            OutlinedTextField(
                value = viewModel.boxLength, onValueChange = { viewModel.boxLength = it },
                label = { Text(text = "Length") },
                modifier = Modifier
                    .padding(5.dp)
                    .weight(1f),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                )
            )
            OutlinedTextField(
                value = viewModel.boxWidth, onValueChange = { viewModel.boxWidth = it },
                label = { Text(text = "Width") },
                modifier = Modifier
                    .padding(5.dp)
                    .weight(1f),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                )
            )
            OutlinedTextField(
                value = viewModel.boxHeight, onValueChange = { viewModel.boxHeight = it },
                label = { Text(text = "Height") },
                modifier = Modifier
                    .padding(5.dp)
                    .weight(1f),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                )
            )
        }



        viewModel.singleJoint = true
        viewModel.joint = "Double"

        if (viewModel.boxLength.isNotBlank() &&
            viewModel.boxWidth.isNotBlank() &&
            viewModel.boxHeight.isNotBlank()
            && viewModel.gsm.isNotBlank() &&
            viewModel.boxLength.indexOf(",") == -1 &&
            viewModel.boxWidth.indexOf(",") == -1 && viewModel.boxHeight.indexOf(
                ","
            ) == -1 &&
            viewModel.boxLength.indexOf("-") == -1 && viewModel.boxWidth.indexOf("-") == -1 && viewModel.boxHeight.indexOf(
                "-"
            ) == -1
        ) {
            viewModel.boardSize = "empty"
            viewModel.boxSize =
                "${viewModel.boxLength} x ${viewModel.boxWidth} x ${viewModel.boxHeight}  $selectedOption"
//            if(checked && tempWidth==null){
//                checked=!checked
//            }
            if(tempWidth!=null){
                viewModel.boxCalCulation(
                    viewModel.boxLength,
                    viewModel.boxWidth,
                    viewModel.boxHeight,
                    tempWidth.toString(),
                    checked,
                    selectedOption
                )
            }else{
                viewModel.boxCalCulation(
                    viewModel.boxLength,
                    viewModel.boxWidth,
                    viewModel.boxHeight,
                    tempWidth.toString(),
                    false,
                    selectedOption
                )
            }


            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
                    .align(Alignment.CenterHorizontally)
                    .background(
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        shape = RoundedCornerShape(50.dp)
                    )

            ) {
                Text(
                    text = "Per Box Weight :  ${viewModel.weight}",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(5.dp)
                        .align(Alignment.Center),
                    fontSize = MaterialTheme.typography.bodyLarge.fontSize
                )

            }
            Text(
                text = "This weight include box production waste it will differ -15 gram to -25 gram",
                modifier = Modifier
                    .padding(5.dp)
                    .align(Alignment.CenterHorizontally),
                textAlign = TextAlign.Center
            )

        }

    }
}
