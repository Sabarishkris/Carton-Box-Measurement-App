package com.example.cartonboxmeasurementapp.data

import kotlinx.coroutines.flow.Flow

interface ReportRepository {

    suspend fun insert(report: Report)

    suspend fun delete(report: Report)

    suspend fun getReportById(id:Int):Report?

    fun getReports(): Flow<List<Report>>

    suspend fun deleteAllReports()
}