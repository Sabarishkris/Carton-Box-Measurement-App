package com.example.cartonboxmeasurementapp.di

import android.app.Application
import androidx.room.Room
import com.example.cartonboxmeasurementapp.data.ReportDatabase
import com.example.cartonboxmeasurementapp.data.ReportRepository
import com.example.cartonboxmeasurementapp.data.ReportRepositoryImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideReportDatabase(app: Application): ReportDatabase {
        return Room.databaseBuilder(app, ReportDatabase::class.java, "report").build()
    }

    @Provides
    @Singleton
    fun provideReportRepository(db:ReportDatabase):ReportRepository{
        return ReportRepositoryImpl(db.dao)
    }
}