package com.example.cartonboxmeasurementapp.ui.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cartonboxmeasurementapp.data.Report
import com.example.cartonboxmeasurementapp.data.ReportRepository
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import javax.inject.Inject

@HiltViewModel
class CalculationViewModel @Inject constructor(
    private val repository: ReportRepository
) : ViewModel() {

    //    var report by mutableStateOf<Report?>(null)
//        private set

    var currentRoute by mutableStateOf(Route.BOX_SHAPE)

    private val _uiEvent = Channel<UiEvents>()
    val uiEvents = _uiEvent.receiveAsFlow()
    var companyName by mutableStateOf("")
    var ply by mutableStateOf("")

    var gsm by mutableStateOf("")

    var reelSize by mutableStateOf("")

    var boxCount by mutableStateOf("1")

    var joint by mutableStateOf("")
    var singleJoint by mutableStateOf(false)

    var boxSize by mutableStateOf("")
    var boardSize by mutableStateOf("")


    var weight by mutableStateOf("")

    var BoardScreen by mutableStateOf(false)

    var BoxScreen by mutableStateOf(true)
    var boxLoadAbility by mutableStateOf("")
    var boxLength by mutableStateOf("")
    var boxHeight by mutableStateOf("")
    var boxWidth by mutableStateOf("")
    var boardLength by mutableStateOf("")
    var boardHeight by mutableStateOf("")

    fun onEvent(event: ReportScreenEvent) {
        when (event) {
            ReportScreenEvent.onSaveReportClicked -> {

                if (companyName.isBlank() || ply.isBlank() || gsm.isBlank() || reelSize.isBlank() ||
                    boxCount.isBlank() || singleJoint && boardSize.isBlank() || !singleJoint && boxSize.isBlank()
                ) {
                    onSendUiEvent(
                        UiEvents.ShowSnackBar(
                            message = "Field can't be empty "
                        )
                    )
                    return
                }
                viewModelScope.launch(Dispatchers.IO) {
                    repository.insert(
                        Report(
                            companyName = companyName,
                            joint = joint,
                            singleJoint = singleJoint,
                            ply = ply,
                            gsm = gsm,
                            reelSize = reelSize,
                            boxCount = boxCount,
                            boxSize = boxSize,
                            boardSize = boardSize,
                            weight = weight
                        )
                    )

                }
                onSendUiEvent(UiEvents.PopBackStack)
            }

            ReportScreenEvent.onBoxCalcluationClicked -> {
//                BoardScreen = true
//                BoxScreen = false
                onSendUiEvent(UiEvents.Navigate(Route.BOX_SCREEN))
            }

            ReportScreenEvent.onBoardCalculationClicked -> {
//                BoardScreen = false
//                BoxScreen = true
                onSendUiEvent(UiEvents.Navigate(Route.BOARD_SCREEN))
            }

            else -> Unit
        }
    }

    fun boardCalcluation(boardLength: String, boardHeight: String) {
        var w: Double? = null
        var l: Double? = null
        var h: Double? = null
        if (boardLength.equals(reelSize) || boardLength.equals(reelSize)) {
            try {
                l = boardLength.toDouble()
                h = boardHeight.toDouble()
            } catch (e: Exception) {
                onSendUiEvent(UiEvents.ShowSnackBar("Invalid Board length or height remove this '-' "))
            }
            if (l != null && h != null) {
                w = ((l * h) * gsm.toInt()) / 1550000
                w /= boxCount.toInt()
            }
            val num = BigDecimal(w.toString())
            val round = num.setScale(3, RoundingMode.HALF_UP)
            weight = "$round Kg"
        } else {
            onSendUiEvent(UiEvents.ShowSnackBar("Invalid Board Size reel size not matching"))
            weight = ""
            return
        }


    }


    private fun onSendUiEvent(events: UiEvents) {
        viewModelScope.launch {
            _uiEvent.send(events)
        }

    }

    fun boxCalCulation(
        length: String,
        width: String,
        height: String,
        match: String,
        checked: Boolean,
        selectedOption: String
    ) {
        viewModelScope.launch(Dispatchers.Default) {
            var l: Double? = null
            var w: Double? = null
            var h: Double? = null
            try {
                l = length.toDouble()
                w = width.toDouble()
                h = height.toDouble()
            } catch (e: Exception) {
                onSendUiEvent(UiEvents.ShowSnackBar("Invalid character remove (',' '-') length or width or height "))
            }
            var ans: Double? = null
            if (l != null && w != null && h != null) {
                if (selectedOption == "CM") {
                    l *= 0.3937
                    w *= 0.3937
                    h *= 0.3937

                } else if (selectedOption == "MM") {
                    l /= 25.4
                    w /= 25.4
                    h /= 25.4
                }


                if (checked && match!=null) {
                    Log.d("check", "${(l + w + 2)} ${match} ")
                    ans = ((l + w + 2) * match.toDouble()) * 2 * gsm.toInt() / 1550000

                } else {
                    Log.d(
                        "Cal",
                        "${(w + h + 0.60)} ${(l + w + 2)} ${(((w + h + 0.60) * (l + w + 2)) * gsm.toInt()) / 1550000}"
                    )

                    if (ply.toInt() < 5) {
                        ans = (((w + h + 0.50) * (l + w + 2)) * 2 * gsm.toInt()) / 1550000
                    } else {
                        ans = (((w + h + 0.75) * (l + w + 2)) * 2 * gsm.toInt()) / 1550000
                    }
                }
            }


            val num = BigDecimal(ans.toString())
            val round = num.setScale(3, RoundingMode.HALF_UP)
            weight = "$round Kg"
        }
    }

    fun loadAbilty(
        boxLength: String,
        boxWidth: String,
        boxHeight: String,
        selectedOption: String,
        containerCbm: Int
    ) {
        var l: Double? = null
        var w: Double? = null
        var h: Double? = null
        var ans: Double? = null
        try {
            l = boxLength.toDouble()
            w = boxWidth.toDouble()
            h = boxHeight.toDouble()
        } catch (e: Exception) {
            onSendUiEvent(UiEvents.ShowSnackBar("Invalid character remove (',' '-') length or width or height "))
        }
        if (l != null && w != null && h != null &&
            l > 0 && w > 0 && h > 0
        ) {
            if (selectedOption == "MM") {
                l /= 10
                w /= 10
                h /= 10
            } else if (selectedOption == "INCH") {
                l *= 2.54
                w *= 2.54
                h *= 2.54
            }
            var cbm = (l * w * h) / 1000000
            Log.d("msg", cbm.toString())
            ans = containerCbm / cbm
            boxLoadAbility = Math.round(ans).toString()
        } else {
            onSendUiEvent(UiEvents.ShowSnackBar("Invalid Carton Size"))
        }

    }

    fun cylinderLoadAbilty(
        cylinderRadius: String,
        cylinderHeight: String,
        selectedOption: String,
        containerCbm: Int
    ) {
        boxLoadAbility = ""
        var r: Double? = null
        var h: Double? = null
        var ans: Double? = null
        try {
            r = cylinderRadius.toDouble()
            h = cylinderHeight.toDouble()
        } catch (e: Exception) {
            onSendUiEvent(UiEvents.ShowSnackBar("Invalid character remove (',' '-') length or width or height "))
        }
        if (r != null && h != null && r > 0 && h > 0) {
            if (selectedOption == "MM") {
                r /= 1000
                h /= 1000
            } else if (selectedOption == "INCH") {
                r /= 39.37
                h /= 39.37
            } else if (selectedOption == "CM") {
                r /= 100
                h /= 100
            } else if (selectedOption == "FEET") {
                r *= 0.305
                h *= 0.305
            }
            r /= 2
            var num = BigDecimal(r.toString())
            r = num.setScale(2, RoundingMode.HALF_UP).toDouble()
            num = BigDecimal(h.toString())
            h = num.setScale(2, RoundingMode.HALF_UP).toDouble()
            var cbm = 3.14 * r * r * h
            num = BigDecimal(cbm.toString())
            cbm = num.setScale(2, RoundingMode.HALF_UP).toDouble()
            ans = containerCbm / cbm

            Log.d("selected", "$selectedOption  ${r} ${h} $cbm $ans")
            boxLoadAbility = Math.round(ans).toString()
        } else {
            onSendUiEvent(UiEvents.ShowSnackBar("Invalid Carton Size"))
        }
    }

}