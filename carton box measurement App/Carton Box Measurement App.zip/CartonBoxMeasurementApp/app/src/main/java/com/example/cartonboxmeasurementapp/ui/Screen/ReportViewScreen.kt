package com.example.cartonboxmeasurementapp.ui.Screen

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.cartonboxmeasurementapp.R
import com.example.cartonboxmeasurementapp.ui.viewmodel.ReportScreenViewModel
import com.example.cartonboxmeasurementapp.ui.viewmodel.ReportViewScreenViewModel

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportViewScreen(
    navController: NavHostController,
    viewModel: ReportViewScreenViewModel = hiltViewModel()
) {
    val report=viewModel.report
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    report?.let { Text(it.companyName) }

                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            )
        }
    ) { innerpadding ->
        Scaffold(
            modifier = Modifier
                .padding(innerpadding)
                .fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize().padding(start = 10.dp, end = 10.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                report?.companyName?.let { it1 ->
                    Text(
                        text = it1,
                        fontSize = MaterialTheme.typography.titleLarge.fontSize,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))

                if (report?.singleJoint != true) {
                    Image(
                        painter = painterResource(id = R.drawable.board),
                        contentDescription = "Board"
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                   report?.boardSize.let { it1 -> Text(text = "Board Size : $it1") }

                    Spacer(modifier = Modifier.height(5.dp))
                    report?.joint?.let { it1 -> Text(text = "Box Joint : $it1") }
                } else {
                    Image(
                        painter = painterResource(id = R.drawable.cartonbox),
                        contentDescription = "Box"
                    )
                    Spacer(modifier = Modifier.height(5.dp))

                    Text(text = "Box Size : ${report.boxSize}")
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(text = "Box Joint : ${report.joint}")
                }

                Spacer(modifier = Modifier.height(5.dp))
                HorizontalDivider(modifier = Modifier.padding(start = 8.dp, end = 8.dp))

                Row (modifier = Modifier.padding(5.dp)){
                    Image(
                        painter = painterResource(id = R.drawable.ply),
                        contentDescription = "Ply",
                        modifier = Modifier
                            .width(100.dp)
                            .height(80.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Column {
                        Text(text = "Boy Layer",
                            fontSize = MaterialTheme.typography.titleMedium.fontSize,
                            fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(3.dp))

                        report?.ply?.let { it1 ->
                            Text(
                                text = it1,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                    }

                }
                HorizontalDivider(modifier = Modifier.padding(start = 8.dp, end = 8.dp))
//                Spacer(modifier = Modifier.height(5.dp))
                Row (modifier = Modifier.padding(5.dp)){
                    Image(
                        painter = painterResource(id = R.drawable.reel),
                        contentDescription = "reel",
                        modifier = Modifier
                            .width(100.dp)
                            .height(80.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Column {
                        Text(text = "Reel Size  ",
                        fontSize = MaterialTheme.typography.titleMedium.fontSize,
                        fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(3.dp))

                        report?.reelSize?.let { it1 ->
                            Text(
                                text = it1,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                    }

                }
                HorizontalDivider(modifier = Modifier.padding(start = 8.dp, end = 8.dp))
//                Spacer(modifier = Modifier.height(5.dp))
                Row (modifier = Modifier.padding(5.dp)){
                    Image(
                        painter = painterResource(id = R.drawable.gsm),
                        contentDescription = "gsm",
                        modifier = Modifier
                            .width(100.dp)
                            .height(80.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Column {
                        Text(text = "GSM  ",
                            fontSize = MaterialTheme.typography.titleMedium.fontSize,
                            fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(3.dp))

                        report?.gsm?.let { it1 ->
                            Text(
                                text = it1,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                    }

                }
                HorizontalDivider(modifier = Modifier.padding(start = 8.dp, end = 8.dp))

                Row (modifier = Modifier.padding(5.dp)){
                    Image(
                        painter = painterResource(id = R.drawable.weight),
                        contentDescription = "Ply",
                        modifier = Modifier
                            .width(100.dp)
                            .height(80.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Column {
                        Text(text = "Per Box Weight",
                            fontSize = MaterialTheme.typography.titleMedium.fontSize,
                            fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(3.dp))
                        Spacer(modifier = Modifier.height(3.dp))
                        report?.weight?.let { it1 ->
                            Text(
                                text = it1,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                    }

                }

            }
        }
    }
}