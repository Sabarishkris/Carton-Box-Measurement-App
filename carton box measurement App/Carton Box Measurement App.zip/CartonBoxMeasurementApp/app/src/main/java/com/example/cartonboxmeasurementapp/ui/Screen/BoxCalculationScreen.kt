package com.example.cartonboxmeasurementapp.ui.Screen

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.R
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.ui.viewmodel.CalculationViewModel
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents

@SuppressLint("UnrememberedMutableState", "SuspiciousIndentation")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoxCalculationScreen(
    navController: NavHostController,
    viewModel: CalculationViewModel = hiltViewModel()
) {
    val scaffold = remember {
        SnackbarHostState()
    }
    var tempWidth: String? = null
    var length by mutableStateOf("")
    var width by mutableStateOf("")
    val radioOptions = listOf("MM", "CM", "INCH")
    val (selectedOption, onOptionSelected) = remember { mutableStateOf(radioOptions[2]) }
    var height by mutableStateOf("")
    val uiEvents = viewModel.uiEvents.collectAsState(initial = null)
    var checked by remember {
        mutableStateOf(false)
    }


    Scaffold(snackbarHost = { SnackbarHost(scaffold, modifier = Modifier.padding(bottom = 80.dp)) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Box Calculation",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        navController.popBackStack(
                            route = Route.REPORT_LIST,
                            inclusive = false
                        )
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }, actions = {
                    if (viewModel.companyName.isNotBlank() &&
                        length.isNotBlank()
                        && width.isNotBlank()
                        && height.isNotBlank()
                    ) {
                        IconButton(onClick = {
                            viewModel.onEvent(ReportScreenEvent.onSaveReportClicked)
                            if (viewModel.weight.isNotBlank()) {
                                navController.popBackStack(
                                    route = Route.REPORT_LIST,
                                    inclusive = false
                                )
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Save",
                                tint = MaterialTheme.colorScheme.onSurface
                            )

                        }
                    }
                }
            )

        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                contentColor = MaterialTheme.colorScheme.onSurface
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        modifier = Modifier
                            .padding(8.dp)
                            .clickable { viewModel.onEvent(ReportScreenEvent.onBoxCalcluationClicked) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            painter = if (viewModel.BoxScreen)
                                painterResource(id = R.drawable.boxselectedicon)
                            else painterResource(
                                id = R.drawable.boxunselecticon
                            ),
                            contentDescription = "Box",
                            modifier = Modifier
                                .width(30.dp)
                                .height(30.dp)
                        )
                        Text(text = "Box", style = MaterialTheme.typography.bodySmall)
                    }
                    Column(
                        modifier = Modifier
                            .padding(8.dp)
                            .clickable { viewModel.onEvent(ReportScreenEvent.onBoardCalculationClicked) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            painter = if (viewModel.BoardScreen) painterResource(id = R.drawable.selectedboard) else painterResource(
                                id = R.drawable.unselectboard
                            ),
                            contentDescription = "Board",
                            modifier = Modifier
                                .width(30.dp)
                                .height(30.dp)
                        )
                        Text(text = "Board", style = MaterialTheme.typography.bodySmall)
                    }

                }
            }
        }
    ) { innerPadding ->

        uiEvents.value?.let { event ->
            LaunchedEffect(key1 = event) {
                Log.d("msgl", "enter")
                when (event) {
                    is UiEvents.Navigate -> {
                        if (event.route != Route.BOX_SCREEN) {
                            navController.navigate(event.route)
                        }
                    }

                    is UiEvents.ShowSnackBar -> {
                        scaffold.showSnackbar(
                            message = event.message,
                        )
                    }

                    else -> Unit
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = viewModel.companyName, onValueChange = { viewModel.companyName = it },
                label = { Text(text = "Company Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1
            )
            viewModel.joint = "Single"
            viewModel.singleJoint = false

            OutlinedTextField(
                value = viewModel.ply, onValueChange = { viewModel.ply = it },
                label = { Text(text = "Box Layer") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                )
            )
            OutlinedTextField(
                value = viewModel.gsm, onValueChange = { viewModel.gsm = it },
                label = { Text(text = "Total GSM") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                )
            )
            Row {
                OutlinedTextField(
                    value = viewModel.reelSize, onValueChange = { viewModel.reelSize = it },
                    label = { Text(text = "Reel Size in inch") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(5.dp),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Done
                    )
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Match reel Size")
                    Checkbox(checked = checked, onCheckedChange = { checked = it })
                }
            }
            if (checked) {
                OutlinedTextField(
                    value = viewModel.boxCount, onValueChange = { viewModel.boxCount = it },
                    label = { Text(text = "Box Count") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(5.dp),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Done
                    )
                )
//                viewModel.boxCount="1"
                if (viewModel.boxCount.isNotBlank() && viewModel.reelSize.isNotBlank()) {
                    try {
                        val temp: Double =
                            viewModel.reelSize.toDouble() / viewModel.boxCount.toDouble()
                        tempWidth = temp.toString()
                    } catch (e: Exception) {
                        e.printStackTrace()
                        UiEvents.ShowSnackBar("Invalid Box Count number")
                    }

                    Log.e("Except", "$tempWidth")
                }


            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp)
            ) {
                Row {
                    radioOptions.forEach { text ->
                        Row(
                            Modifier
                                .selectable(
                                    selected = (text == selectedOption),
                                    onClick = { onOptionSelected(text) }
                                ), horizontalArrangement = Arrangement.SpaceEvenly
                        ) {

                            RadioButton(
                                selected = (text == selectedOption),
                                modifier = Modifier.padding(all = Dp(value = 8F)),
                                onClick = {
                                    onOptionSelected(text)
                                }
                            )
                            Text(
                                text = text, modifier = Modifier.align(Alignment.CenterVertically)
                            )
                        }
                    }
                }
            }
            Row(
                modifier = Modifier.padding(5.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                OutlinedTextField(
                    value = length, onValueChange = { length = it },
                    label = { Text(text = "Length") },
                    modifier = Modifier
                        .padding(5.dp)
                        .weight(1f),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    )
                )
                OutlinedTextField(
                    value = width, onValueChange = { width = it },
                    label = { Text(text = "Width") },
                    modifier = Modifier
                        .padding(5.dp)
                        .weight(1f),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    )
                )
                OutlinedTextField(
                    value = height, onValueChange = { height = it },
                    label = { Text(text = "Height") },
                    modifier = Modifier
                        .padding(5.dp)
                        .weight(1f),
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    )
                )
            }



            viewModel.singleJoint = true
            viewModel.joint = "Double"

            if (length.isNotBlank() && width.isNotBlank() && height.isNotBlank()
                && viewModel.gsm.isNotBlank()
            ) {
                viewModel.boardSize = "empty"
                viewModel.boxSize = "$length x $width x $height  $selectedOption"
                viewModel.boxCalCulation(
                    length,
                    width,
                    height,
                    tempWidth.toString(),
                    checked,
                    selectedOption
                )

                Spacer(modifier = Modifier.height(10.dp))
                Box(modifier = Modifier.fillMaxWidth().padding(10.dp)
                    .align(Alignment.CenterHorizontally)
                    .background(color = MaterialTheme.colorScheme.surfaceContainer, shape = RoundedCornerShape(50.dp))

                ) {
                    Text(
                        text = "Per Box Weight :  ${viewModel.weight}",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(5.dp).align(Alignment.Center),
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize
                    )

                }
                Text(
                    text = "This weight include box production waste it will differ -15 gram to -25 gram",
                    modifier = Modifier
                        .padding(5.dp)
                        .align(Alignment.CenterHorizontally),
                    textAlign = TextAlign.Center
                )

            }

        }
    }


}
