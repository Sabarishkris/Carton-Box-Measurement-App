package com.example.cartonboxmeasurementapp.item

data class DrawerItem(
    val title: String,
    val icon: Any,
)
