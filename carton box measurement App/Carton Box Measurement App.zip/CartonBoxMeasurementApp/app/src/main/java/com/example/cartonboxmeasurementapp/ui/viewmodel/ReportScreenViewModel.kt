package com.example.cartonboxmeasurementapp.ui.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.cartonboxmeasurementapp.data.Report
import com.example.cartonboxmeasurementapp.data.ReportRepository
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReportScreenViewModel @Inject constructor(private val repository: ReportRepository) :
    ViewModel() {
    val reports = repository.getReports()
    private val _uiEvents = Channel<UiEvents>()
    val uiEvents = _uiEvents.receiveAsFlow()
    private var deleteTodo: Report? = null

    fun deleteAllReports() {

        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAllReports()
        }
    }

    fun onEvent(event: ReportScreenEvent) {
        when (event) {
            is ReportScreenEvent.onAddReportClicked ->
                viewModelScope.launch(Dispatchers.IO) {
                    onSendUiEvent(UiEvents.Navigate(Route.BOX_SCREEN))
                }

            is ReportScreenEvent.onDeleteReport ->
                viewModelScope.launch {
                    deleteTodo = event.report
                    repository.delete(event.report)
                    onSendUiEvent(
                        UiEvents.ShowSnackBar(
                            message = "Report deleted "
                        )
                    )
                }

            is ReportScreenEvent.onReportClicked -> {
                Log.d("msg", "${event.report.id}")
                onSendUiEvent(UiEvents.Navigate(Route.VIEW_REPORT + "?reportId=${event.report.id}"))
            }

//            is ReportScreenEvent.onGsmScreenClicked -> {
//                onSendUiEvent(UiEvents.Navigate(Route.GSM_SCREEN))
//            }
//
//            is ReportScreenEvent.onGumScreenClicked -> {
//                onSendUiEvent(UiEvents.Navigate(Route.GUM_SCREEN))
//            }

            is ReportScreenEvent.onHelpScreenClicked -> {
                onSendUiEvent(UiEvents.Navigate(Route.HELP_SCREEN))
            }

            is ReportScreenEvent.onContainerBoxScreenClicked -> {
                onSendUiEvent(UiEvents.Navigate(Route.CONTAINER_BOX_SCREEN))
            }
            is ReportScreenEvent.onWeightCalculationClicked->{
                onSendUiEvent(UiEvents.Navigate(Route.WEIGHT_CALCULATION_SCREEN))
            }

            else -> Unit
        }
    }

    private fun onSendUiEvent(events: UiEvents) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiEvents.send(events)
        }

    }
}