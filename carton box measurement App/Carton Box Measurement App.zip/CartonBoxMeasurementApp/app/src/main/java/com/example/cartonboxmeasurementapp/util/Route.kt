package com.example.cartonboxmeasurementapp.util

object Route {
    const val WEIGHT_CALCULATION_SCREEN="weight_calculation_screen"
    const val HELP_SCREEN="help"
    const val GSM_SCREEN="gsm"
    const val GUM_SCREEN="gum"
//    const val SPLASH="Splash"
    const val REPORT_LIST="report_list"
    const val VIEW_REPORT="view_report"
    const val BOX_SCREEN="box_screen"
    const val BOARD_SCREEN="board_Screen"
    const val CONTAINER_BOX_SCREEN="container_box_Screen"
    const val BOX_SHAPE="box_shape"
    const val CYLINDER_SHAPE="cylinder_shape"
}