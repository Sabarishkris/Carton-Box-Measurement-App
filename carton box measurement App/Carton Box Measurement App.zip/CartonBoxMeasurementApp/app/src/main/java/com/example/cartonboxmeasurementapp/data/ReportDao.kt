package com.example.cartonboxmeasurementapp.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ReportDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(report: Report)

    @Delete
    suspend fun delete(report: Report)

    @Query("Select * from report where id=:id")
    suspend fun getReportById(id: Int): Report?

    @Query("select * from report")
    fun getReports(): Flow<List<Report>>
    @Query("delete from report")
    fun deleteall()
}