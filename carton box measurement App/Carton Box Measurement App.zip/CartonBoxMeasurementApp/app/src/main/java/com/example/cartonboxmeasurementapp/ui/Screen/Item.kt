package com.example.cartonboxmeasurementapp.ui.Screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cartonboxmeasurementapp.data.Report
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import kotlin.reflect.KFunction1

@Composable
fun ReportItem(report: Report ,modifier: Modifier) {
Column(modifier= modifier
    .background(color = MaterialTheme.colorScheme.surface)
    .padding(8.dp)) {
Text(text = report.companyName, fontSize = MaterialTheme.typography.titleLarge.fontSize)
    Spacer(modifier = Modifier.height(5.dp))
    Text(text = if(!report.singleJoint) "Board Size : ${report.boardSize}" else "Box Size : ${report.boxSize}",
        fontSize = MaterialTheme.typography.bodySmall.fontSize,
        fontWeight = FontWeight.W100)
    Spacer(modifier = Modifier.height(5.dp))
    HorizontalDivider(modifier = Modifier.padding(start = 7.dp, end = 7.dp))

}
}