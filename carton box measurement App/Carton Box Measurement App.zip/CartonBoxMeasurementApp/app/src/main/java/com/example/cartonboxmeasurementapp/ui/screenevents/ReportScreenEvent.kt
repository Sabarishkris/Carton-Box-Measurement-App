package com.example.cartonboxmeasurementapp.ui.screenevents

import com.example.cartonboxmeasurementapp.data.Report


sealed class ReportScreenEvent {
    data class onDeleteReport(val report: Report) : ReportScreenEvent()
    data class onReportClicked(val report: Report) : ReportScreenEvent()
    object onAddReportClicked : ReportScreenEvent()
    object onSaveReportClicked:ReportScreenEvent()
    object onBoardCalculationClicked:ReportScreenEvent()
    object onBoxCalcluationClicked:ReportScreenEvent()
    object onGsmScreenClicked:ReportScreenEvent()
    object onGumScreenClicked:ReportScreenEvent()
    object onHelpScreenClicked:ReportScreenEvent()
     object onContainerBoxScreenClicked: ReportScreenEvent()
     object onWeightCalculationClicked: ReportScreenEvent()



}