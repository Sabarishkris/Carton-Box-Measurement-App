package com.example.cartonboxmeasurementapp.ui.Screen
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.data.Report
import com.example.cartonboxmeasurementapp.draweritem.DrawerItem
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.ui.viewmodel.ReportScreenViewModel
import com.example.cartonboxmeasurementapp.util.UiEvents
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.seconds

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "CoroutineCreationDuringComposition")
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ReportsScreen(
    navController: NavHostController,
    viewModel: ReportScreenViewModel = hiltViewModel()
) {
    val items = listOf(
        DrawerItem("GSM Calculation",Icons.Filled.Info),
        DrawerItem("Gum Water Level", Icons.Filled.Warning),
        DrawerItem("Help", Icons.Filled.ThumbUp)
    )
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showMenu by remember { mutableStateOf(false) }
    var selectedItemIndex by rememberSaveable {
        mutableStateOf(0)
    }
    val reports by viewModel.reports.collectAsState(emptyList())
    var showDialog by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier.fillMaxSize()
    ) {

        ModalNavigationDrawer(
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier.width(250.dp) // Set the desired width here
                ) {
//                ModalDrawerSheet {

                    Spacer(modifier = Modifier.height(16.dp))
                    items.forEachIndexed { index, item ->
                        NavigationDrawerItem(
                            label = { Text(text = item.title) },
                            selected = index == selectedItemIndex,
                            onClick = {
                                selectedItemIndex = index
                            Log.d("msg", selectedItemIndex.toString() + "1")

                            when (selectedItemIndex) {
                                0 -> viewModel.onEvent(ReportScreenEvent.onGsmScreenClicked)
                                1 -> viewModel.onEvent(ReportScreenEvent.onGumScreenClicked)
                                2 -> viewModel.onEvent(ReportScreenEvent.onHelpScreenClicked)

                            }
                                scope.launch {
                                    Log.d("msg", selectedItemIndex.toString())
                                    drawerState.close()
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector =item.icon,
                                    contentDescription = null
                                )
                            },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                        )

                    }
                }
            },
            drawerState = drawerState
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Reports") },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer,
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        actions = {
                            IconButton(onClick = {
                                if(reports.isNotEmpty()) {
                                showDialog = true
                            }else{
                                UiEvents.ShowSnackBar("No Reports to delete")
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete All",
                                )

                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                scope.launch {
                                    drawerState.open()
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "menu"
                                )
                            }
                        }
                    )
                },

            ) { innerPadding ->

                val scaffoldState = remember { SnackbarHostState() }
                YesNoDialog(
                    showDialog = showDialog,
                    onDismiss = { showDialog = false },
                    onYesClicked = { viewModel.deleteAllReports() },
                    onNoClicked = { /* Handle No click */ }
                )
                LaunchedEffect(key1 = true) {
//                    Log.d("nav", "Navigating")
                    viewModel.uiEvents.collect { event ->
                        when (event) {
                            is UiEvents.Navigate -> navController.navigate(event.route)
                            is UiEvents.ShowSnackBar -> scaffoldState.showSnackbar(event.message)
                            else -> Unit
                        }
                    }
                }
                Scaffold(snackbarHost = { SnackbarHost(scaffoldState) },
                    modifier = Modifier
                        .padding(innerPadding)
                        .fillMaxSize(),
                    floatingActionButton = {
                        FloatingActionButton(onClick = {
                            viewModel.onEvent(ReportScreenEvent.onAddReportClicked)
                        }) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add"
                            )
                        }
                    }) {
                    LazyColumn {
                        items(items = reports,
                            key = { it.id!! }) { report ->
                            SwipeTODismissItem(
                                item = report,
                                onRemove = {
                                    viewModel.onEvent(
                                        ReportScreenEvent.onDeleteReport(
                                            report
                                        )
                                    )
                                },
                                modifier = Modifier.animateItemPlacement(tween(200)),
                                viewModel = viewModel
                            )

                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SwipeTODismissItem(
    item: Report,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ReportScreenViewModel
) {
    val coroutineScope = rememberCoroutineScope()
    val swipeToDismissBoxState = rememberSwipeToDismissBoxState(
        confirmValueChange = { state ->
            if (state == SwipeToDismissBoxValue.EndToStart) {
                coroutineScope.launch {
                    delay(1.seconds)
                    onRemove()
                }
                true
            } else {
                false
            }
        }
    )
    SwipeToDismissBox(
        state = swipeToDismissBoxState,
        backgroundContent = {
            val backgroundColor by animateColorAsState(
                targetValue =
                when (swipeToDismissBoxState.currentValue) {
                    SwipeToDismissBoxValue.StartToEnd -> Color.Green
                    SwipeToDismissBoxValue.EndToStart -> Color.Red
                    SwipeToDismissBoxValue.Settled -> Color.White
                }, label = ""
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(backgroundColor)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete, contentDescription = "delete",
                    tint = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }, modifier = modifier
    ) {
        ReportItem(
            report = item,
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    viewModel.onEvent(ReportScreenEvent.onReportClicked(item))
                }

        )
    }
}


@Composable
fun YesNoDialog(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    onYesClicked: () -> Unit,
    onNoClicked: () -> Unit
) {
    if (showDialog) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = {
                Text(text = " Delete All Reports ")
                    },
            text = {
                Text(text = "Are you sure you want to proceed ?")
                   },
            confirmButton = {
                TextButton(onClick = {
                    onYesClicked()
                    onDismiss()
                }) {
                    Text(text = "Yes")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    onNoClicked()
                    onDismiss()
                }) {
                    Text("No")
                }
            }
        )
    }
}

