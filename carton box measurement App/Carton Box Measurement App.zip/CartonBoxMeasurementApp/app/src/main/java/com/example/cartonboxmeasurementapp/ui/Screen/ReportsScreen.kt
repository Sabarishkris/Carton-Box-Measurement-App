package com.example.cartonboxmeasurementapp.ui.Screen
//import androidx.compose.material3.DismissDirection
//import androidx.compose.material3.DismissState
//import androidx.compose.material3.DismissValue
//import androidx.compose.material3.Icon
//import androidx.compose.material3.SwipeToDismiss
//import androidx.compose.material3.rememberDismissState
import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.cartonboxmeasurementapp.data.Report
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.ui.viewmodel.ReportScreenViewModel
import com.example.cartonboxmeasurementapp.util.UiEvents
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.seconds

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ReportsScreen(navController: NavHostController, viewModel: ReportScreenViewModel = hiltViewModel()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reports") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }){ innerPadding ->
            val reports by viewModel.reports.collectAsState(emptyList())
            val scaffoldState = remember { SnackbarHostState() }

            LaunchedEffect(key1 = true) {
                Log.d("nav","Navigating")
                viewModel.uiEvents.collect { event ->
                    when (event) {
                        is UiEvents.Navigate -> navController.navigate(event.route)
                        is UiEvents.ShowSnackBar -> scaffoldState.showSnackbar(event.message)
                        else -> Unit
                    }
                }
            }
            Scaffold(snackbarHost = { SnackbarHost(scaffoldState) },
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize(),
                floatingActionButton = {
                    FloatingActionButton( onClick = {
                        viewModel.onEvent(ReportScreenEvent.onAddReportClicked)
                    }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add"
                        )
                    }
                }) {
                LazyColumn{
                    items(items = reports,
                        key = { it.id!! }) { report ->
                        SwipeTODismissItem(
                            item = report,
                            onRemove = { viewModel.onEvent(ReportScreenEvent.onDeleteReport(report)) },
                            modifier = Modifier.animateItemPlacement(tween(200)),
                            viewModel = viewModel
                        )

                    }
                }
            }
        }
}
@Composable
fun SwipeTODismissItem(
    item: Report,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ReportScreenViewModel
){
    val coroutineScope= rememberCoroutineScope()
    val swipeToDismissBoxState= rememberSwipeToDismissBoxState(
        confirmValueChange = {state->
            if(state==SwipeToDismissBoxValue.EndToStart){
                coroutineScope.launch {
                    delay(1.seconds)
                    onRemove()
                }
                true
            }else{
                false
            }
        }
    )
    SwipeToDismissBox(state = swipeToDismissBoxState,
        backgroundContent = {
        val backgroundColor by animateColorAsState(targetValue =
        when(swipeToDismissBoxState.currentValue){
            SwipeToDismissBoxValue.StartToEnd -> Color.Green
            SwipeToDismissBoxValue.EndToStart -> Color.Red
            SwipeToDismissBoxValue.Settled -> Color.White
        }, label = ""
        )
       Box(modifier = Modifier
           .fillMaxSize()
           .background(backgroundColor)){
           Icon(imageVector = Icons.Default.Delete, contentDescription ="delete" ,
               tint = MaterialTheme.colorScheme.surface,
               modifier = Modifier.align(Alignment.Center))
       }
    }, modifier = modifier
        ) {
        ReportItem(
            report = item,
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    viewModel.onEvent(ReportScreenEvent.onReportClicked(item))
                }

        )
    }
}
