package com.example.cartonboxmeasurementapp.ui.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.cartonboxmeasurementapp.data.Report
import com.example.cartonboxmeasurementapp.data.ReportRepository
import com.example.cartonboxmeasurementapp.ui.screenevents.ReportScreenEvent
import com.example.cartonboxmeasurementapp.util.Route
import com.example.cartonboxmeasurementapp.util.UiEvents
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReportViewScreenViewModel @Inject constructor(
    private val repository: ReportRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    var report by mutableStateOf<Report?>(null)
        private set

    init {
        val reportId = savedStateHandle.get<Int>("reportId")
        Log.d("id", "$reportId")
        if (reportId != -1) {
            viewModelScope.launch(Dispatchers.IO) {
                repository.getReportById(reportId!!)?.let { item ->
                    this@ReportViewScreenViewModel.report = item
                }
            }
        }
        Log.d("id", "fetching done")
    }



}