package com.example.cartonboxmeasurementapp.ui.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cartonboxmeasurementapp.data.Report
import com.example.cartonboxmeasurementapp.data.ReportRepository
import com.example.cartonboxmeasurementapp.util.UiEvents
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReportViewScreenViewModel @Inject constructor(
    private val repository: ReportRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    sealed class UiState {
        object Success : UiState()
        object Error : UiState()
        object Loading : UiState()
    }

    var uiState: UiState by mutableStateOf(UiState.Loading)
        private set

    private val _report = MutableLiveData<Report>()
    val report: LiveData<Report> get() = _report

    private val _uiEvents = Channel<UiEvents>()
    val uiEvents = _uiEvents.receiveAsFlow()

    init {
        val reportId = savedStateHandle.get<Int>("reportId") ?: -1
        if (reportId != -1) {
            fetchReport(reportId)
        }
    }

    private fun fetchReport(reportId: Int) {
        viewModelScope.launch {
            try {
                uiState = UiState.Loading
                repository.getReportById(reportId)?.let { item ->
                    _report.value = item
                    uiState = UiState.Success
                    Log.d("ViewModel", "Successfully fetched report")
                } ?: run {
                    uiState = UiState.Error
                    Log.e("ViewModel", "Error fetching report")
                }
            } catch (e: Exception) {
                uiState = UiState.Error
                Log.e("ViewModel", "Exception fetching report", e)
            }
        }
    }
}
